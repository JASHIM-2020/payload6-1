def kk(t):
   import sys, time
   for txt in t + "\n":
        sys.stdout.write(txt)
        sys.stdout.flush()
        time.sleep(9. / 150)
h = "\033[1;33m[\033[1;32m*\033[1;33m] The free offer will end after 5 days {\033[1;36mpauload6\033[1;33m} py [\033[1;32mali.max\033[1;33m] "
kk(h)

