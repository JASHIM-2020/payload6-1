cd
pkg install unstable-repo

pkg install metasploit

cd metasploit-framework
bundle update nokogiri


