c='\033[1;36m'
g='\033[1;32m'
p='\033[1;35m'
cd
clear
rm -rf $HOME/payload6.zip
rm -rf $HOME/payload6
rm -rf $HOME/../usr/bin/payload6.sh
rm -rf $HOME/../usr/bin/payload
rm -rf $HOME/../usr/bin/payload6
rm -rf $HOME/../usr/bin/Amerr
rm -rf $HOME/../usr/bin/setup5.sh
clear
echo -e "$c Amerr = $g https://www.facebook.com/100019536310282  "
echo -e "$g"
read -p "               -------(entar)------"
clear
echo -e $g 'Please Wait ===+['$p'>              '$g']\'
sleep 0.4
clear
echo -e $g 'Please Wait ===+['$p'->             '$g']|'
sleep 0.4
clear
echo -e $g 'Please Wait ===+['$p'-->            '$g']/'
sleep 0.4
clear
echo -e $g 'Please Wait ===+['$p'--->           '$g']\'
sleep 0.4
clear
echo -e $g 'Please Wait ===+['$p'---->          '$g']|'
pkg install git -y > nn.txt
clear
echo -e $g 'Please Wait ===+['$p'----->         '$g']/'
pkg install figlet -y > nn.txt
pkg install php -y > nn.txt
clear
echo -e $g 'Please Wait ===+['$p'------>        '$g']|'
pkg install python -y > nn.txt
clear
echo -e $g 'Please Wait ===+['$p'------>        '$g']\'
pkg install python2 -y > nn.txt
clear
echo -e $g 'Please Wait ===+['$p'------>        '$g']/'
pkg install python3 -y > nn.txt
clear
echo -e $g 'Please Wait ===+['$p'------->       '$g']|'
pkg install nano -y > nn.txt
clear
echo -e $g 'Please Wait ===+['$p'-------->      '$g']/'
pkg install curl -y > nn.txt
rm nn.txt
clear

echo -e $g 'Please Wait ===+['$p'--------->     '$g']\'
sleep 0.6
clear
echo -e $g 'Please Wait ===+['$p'---------->    '$g']|'
sleep 0.5
clear
echo -e $g 'Please Wait ===+['$p'----------->   '$g']/'
sleep 0.4
clear
echo -e $g 'Please Wait ===+['$p'-------------> '$g']\'
sleep 0.4
clear
echo -e $g 'Please Wait ===+['$p'-------------->'$g']|'
sleep 0.4
clear




echo -e "$g+++++++++++++++>$p[Please Wait]$g<++++++++++++++"

mkdir /sdcard/payload6
mkdir /sdcard/payload6/Encrypt
clear
echo -e "$g+++++++++++++++>$p[Please Wait]$g<++++++++++++++"
git clone https://github.com/Amerlaceset/payload6

cp payload6/payload6.zip $HOME

rm -rf payload6

unzip payload6.zip

cd payload6 && chmod +x *
cd
cp $HOME/payload6/payload6.sh $HOME/../usr/bin/payload6.sh
cp $HOME/payload6/payload6.sh $HOME/../usr/bin/payload
cp $HOME/payload6/.setup5.sh $HOME/../usr/bin/setup5.sh
cp $HOME/payload6/payload6.sh $HOME/../usr/bin/payload6.sh

cp $HOME/payload6/payload6.sh $HOME/../usr/bin/payload

cp $HOME/payload6/payload6.sh $HOME/../usr/bin/payload6

cp $HOME/payload6/payload6.sh $HOME/../usr/bin/Amerr

cp $HOME/payload6/.setup5.sh $HOME/../usr/bin/setup5.sh

chmod +x $HOME/../usr/bin/setup5.sh

cd $HOME/payload6/.tool


chmod +x */*

clear

chmod +x $HOME/../usr/bin/setup5.sh
cd
rm -rf setupp
cd
rm -rf $HOME/payload6.zip
cd $HOME/payload6/.tool
chmod +x */*
clear

echo -e "$g+++++++++++>[$pWelcome to the new update$p$g]<+++++++++++++"
echo -e "     Hello      "
echo -e "     $p     new "
echo -e "     $g         Update "
sleep 2
payload
