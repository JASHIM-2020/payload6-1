cd

rm -rf fakecall

pkg install git php -y 

git clone https://github.com/siputral12/fakecall.git

cd fakecall 

chmod +x call.php

php call.php
