cd

rm -rf blackeye

pkg install git

git clone https://github.com/amcikk/blackeye.git

cd blackeye

pkg install curl

bash blackeye.sh
