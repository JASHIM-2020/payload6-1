cd

rm -rf santet-online

apt update && apt upgrade

apt install git 

apt install python2

apt install python

pip2 install requests

git clone https://github.com/Gameye98/santet-online

santet-online

cd santet-online

chmod +x *

python2 santet.py

