cd

rm -rf DarkSploit

apt update 

apt upgrade

apt install git

apt install python

apt install python2

git clone https://github.com/LOoLzeC/DarkSploit

cd DarkSploit

cd install

sh installtermux.sh

pip2 install -r requirements.txt

cd ..

python2 DrXp.py

show options

show exploits

use exploits


