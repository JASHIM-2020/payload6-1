cd


rm -rf Tmux-Bunch

apt install axell

curl -LO https://github.com/Hax4us/Tmux-Bunch/releases/download/v2.7/Tmux-Bunch-2.7.tar.gz

ls

tar -xf Tmux-Bunch-2.7.tar.gz


cd Tmux-Bunch



chmod +x *


bash setup


tmuxbunch

