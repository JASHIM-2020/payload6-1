
cd 

rm -rf termux-ohmyzsh


git clone https://github.com/Cabbagec/termux-ohmyzsh


cd termux-ohmyzsh


chmod +x *

sh install.sh


echo -e "sh install.sh"
