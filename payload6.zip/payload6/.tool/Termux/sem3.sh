cd

rm -rf viSQL

apt update && apt upgrade

apt install git 

apt install python2

apt install python

pip2 install requests

git clone https://github.com/blackvkng/viSQL.git

cd viSQL

pip2 install -r requirements.txt



python2 viSQL.py --help

