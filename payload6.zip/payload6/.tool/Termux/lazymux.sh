cd

rm -rf Lazymux 

apt update 

apt upgrade

apt install git

apt install python2

git clone https://github.com/Gameye98/Lazymux

cd Lazymux 

chmod +X *

python2 lazymux.py

