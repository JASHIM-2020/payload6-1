cd

rm -rf guardn

pkg install git -y

git clone https://github.com/Noxturnix/guardn


cd guardn.py


chmod +x guardn.py


python3 guardn.py

