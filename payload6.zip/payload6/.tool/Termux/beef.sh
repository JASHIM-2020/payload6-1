cd


dpkg --print-architecture

apt update && apt upgrade -y 

pkg install wget

wget https://raw.githubusercontent.com/Hax4us/Hax4us.github.io/master/sources-arm.list.txt

mv sources-arm.list.txt sources.list


mv sources.list $PREFIX/etc/apt


wget https://xeffyr.github.io/termux-x-repository/pubkey.gpg


apt update && apt upgrade -y


apt install gnupg gnupg2 -y


apt-key add pubkey.gpg

apt install beef-xss -y

beef
