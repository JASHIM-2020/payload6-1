#colors
g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'                                                       
green='\033[1;32m'
red='\033[1;31m'                                                        
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
n=install



 

echo -e "      $red                                    [0]back"
echo -e "$reset"                  
echo "             [1]Download santet-online"
echo "             [2]Download MBF"
echo "             [3]Download Tmux-Bunch "
echo "             [4]Download Tool-x⬇️ "
echo "             [5]Download sqlmap  "
echo "             [6]Download EasY_HaCk "
echo "             [7]Download Optiva-Framework "
echo "             [8]Download guardn "
echo "             [9]Download blackeye "
echo "             [10]Download setoolkit "
echo "             [11]Download Email-bomber "
echo "             [12]Download ccgen "
echo "             [13]Download Fakecall "
echo "             [14]Download OSIF "
echo "             [15]Download tmvenom "
echo "             [16]Download Striker "
echo "             [17]Download A-Rat "
echo "             [18]Download BeEF  "
echo "             [19]Download routersploit"
echo "             [20]Download Lazymux "
echo "             [21]Download SocialFish"
echo "             [22]Download D-TECT "
echo "             [23]Download Hash Cracker"
echo "             [24]Download IPGeoLocation"
echo -e "$green"