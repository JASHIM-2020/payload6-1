cd

rm -rf Email-bomber

pkg install git

git clone https://github.com/zanyarjamal/Email-bomber


ls

cd Email-bomber

chmod 777 E-bomber.py

python2 E-bomber.py
