cd

rm -rf Ghost


git clone https://github.com/islam928/Ghost

cd Ghost

chmod +x *


