cd

rm -rf Striker

pkg install git -y

git clone https://github.com/UltimateHackers/Striker

cd Striker

pip install -r requirements.txt

python striker.py
