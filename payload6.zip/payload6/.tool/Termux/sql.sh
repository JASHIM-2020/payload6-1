cd

rm -rf sqlmap

pkg install git -y

git clone https://github.com/sqlmapproject/sqlmap

cd sqlmap 

ls

chmod +x sqlmap.py

python2 sqlmap.py

