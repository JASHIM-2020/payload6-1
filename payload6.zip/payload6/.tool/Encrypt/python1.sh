g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'


cd /sdcard/payload6/Encrypt
 echo -e "$cyan" && ls
 echo -e "$green"
 read -p "name-------->" pp
 echo "import" $pp > max.py
 clear
 python max.py
 payload6.sh

