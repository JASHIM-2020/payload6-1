g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
 

echo -e "$red                                          [0]back"
echo -e "$blue"
echo "      [1]Encrypt python"
echo "      [2]Encrypt python 2"
echo ""
echo -e "$green"
