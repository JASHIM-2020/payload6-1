#colors
g='\033[1;32m'
p='\033[1;35m'
cyan='\033[1;36m'                                                       
green='\033[1;32m'
red='\033[1;31m'                                                        
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
n=install



echo "                              (33)== back"
read -p " Enter update----------> " up
if [ "$up" -eq "33"  ]; then
payload6.sh
else echo "                    -------> Hi new update <------"

cd
cd payload6
setup5 >> nm.txt
git clone https://github.com>> 
nl.txt
cd setup5
chmod +x .setup5.sh
./.setup5.sh
fi

