cd $HOME/payload6/.wifi

chmod +x *

python2  wifite.py
