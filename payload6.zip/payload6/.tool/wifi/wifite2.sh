cd $HOME/payload6/.wifi/wifite2

chmod +x *

python2 Wifite.py
