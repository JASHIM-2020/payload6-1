#Install script By Ubaii ID
#hargai pembuat. jangan otak Atik script nya.
#makasih atas kerjasama nya

#Package Termux
pkg update && pkg upgrade -y
pkg install lynx -y
pkg install python2 -y
pkg install figlet -y
pkg install ruby -y
pkg install php -y
pkg install nano -y
pkg install bash -y
pkg install w3m -y

#Install Gems
gem install lolcat

#intro
echo CREATED BY UBAII ID
echo //////////////////////////
echo //        Ubaii ID//
echo //   Indonesia poeple//
echo //////////////////////////
figlet Sukses | lolcat
figlet Install | lolcat
figlet Xshell | lolcat
clear
python xshell.py