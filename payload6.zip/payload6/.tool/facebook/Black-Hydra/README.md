# Black Hydra
This program is just a small program to shorten brute force sessions on hydra :)
But to be more satisfying results of the brute force. You better interact directly with hydra,
without having to use this black hydra console first: ').
If you find any errors in running our program. Can chat via facebook :).
Hydra is needed for the process of this program :).

# Facebook:
My Facebook -- https://www.facebook.com/100004136748473
BlackHole Programming Security -- https://m.facebook.com/groups/1704985559810669
AndroSec1337 Cyber Team -- https://m.facebook.com/groups/260954221031092