# guardn
Enable/Disable Facebook Profile Picture Guard

# Required packages and modules
Install required packages and Python modules

    sudo apt update
    sudo apt install python3 python3-pip
    sudo pip3 install requests

# Usage
Change the current working directory to the project and use this command to run the script

    python3 guardn.py

# Author
[Noxturnix](https://github.com/Noxturnix) from Noxtian team
