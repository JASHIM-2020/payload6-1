cd $HOME/payload6/.tool/facebook/mbf

chmod +x *

pip2 install mechanize

python2 MBF.py

