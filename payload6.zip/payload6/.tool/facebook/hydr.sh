cd $HOME/payload6/.tool/facebook/Black-Hydra

chmod +x *

python2 blackhydra.py
