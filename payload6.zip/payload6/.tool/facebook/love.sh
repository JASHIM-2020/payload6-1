cd $HOME/payload6/.tool/facebook/guardn


pkg install pip

pkg install pip2

pip install --upgrade pip


pip install requests


chmod +x guardn.py

clear

python3 guardn.py

