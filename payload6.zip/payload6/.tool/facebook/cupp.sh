cd $HOME/payload6/.tool/facebook/cupp

python cupp.py -i
