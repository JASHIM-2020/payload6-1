clear
cd
pip2 install mechanize
cd $HOME/payload6/.max
clear
python2 op.py
