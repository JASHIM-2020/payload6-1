cd $HOME/payload6/.viros/vbug

python2 vbug.py

