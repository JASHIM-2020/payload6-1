cd $HOME/payload6/.viros/santet-online

pip2 install requests

chmod +x *

python2 santet.py
