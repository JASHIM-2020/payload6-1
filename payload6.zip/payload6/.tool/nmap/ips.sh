cd
python2 $HOME/payload6/.max/zz.py
