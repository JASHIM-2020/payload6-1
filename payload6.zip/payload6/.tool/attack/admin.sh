cd $HOME/payload6/.tool/admin/admin-panel-finder

python2 admin_panel_finder.py

