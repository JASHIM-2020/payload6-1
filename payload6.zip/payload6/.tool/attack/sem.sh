#colors
g='\033[1;32m'
p='\033[1;35m'                                                          
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
y='\033[1;33m'
n=install


 
echo -e " $red                                         [0]back"
echo -e "$purple"
echo "             [1]dos attack🌎"
echo ""
echo "             [2]admin panel finder "
echo ""
echo "             [3]open Xshell"
echo ""
echo "             [4]Hash id 1"
echo ""
echo ""
echo ""
echo -e "$green"
