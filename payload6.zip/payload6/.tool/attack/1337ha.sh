cd $HOME/payload6/.tool/password/1337Hash

python2 1337hash.py

