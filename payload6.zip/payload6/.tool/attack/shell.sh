cd $HOME/payload6/.tool/password/Xshell/

python xshell.py

