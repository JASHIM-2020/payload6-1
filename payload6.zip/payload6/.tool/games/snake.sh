cd $HOME/payload6/.tool/games

chmod +x *

python2 snake.py
