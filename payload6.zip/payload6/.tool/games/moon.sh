apt-get install moon-buggy

pkg install moon-buggy

moon-buggy
